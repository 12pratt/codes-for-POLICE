import { Component } from '@angular/core';

@Component({
  selector: 'app-calc',
  templateUrl: './calc.html',
  styleUrls: ['./calc.css']
})
export class Calc  {

  display: string = '';

   append(value: string): void {
    this.display += value;
  }

  clear(): void {
    this.display = '';
  }

  calculate() {
  try {
    this.display = new Function('return ' + this.display)();
  } catch (error) {
    this.display = "Error";
  }
}
}