import { Component, signal } from '@angular/core';
import { Calc } from './calc/calc';


@Component({
  selector: 'app-root',
  imports: [Calc],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  protected readonly title = signal('Calculator');
}