import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';

@Component({
  selector: 'app-structural',
  imports: [CommonModule],
  templateUrl: './structural.html',
  styleUrl: './structural.css',
})
export class Structural {
  isLoggedIn :boolean=false;
login(){
  this.isLoggedIn=true
}
logout()
{
  this.isLoggedIn=false

}
course:string[]=['angular','react','java script','node']
  // ====== ngSwitch ======
  role: string = 'admin';

  // ====== Methods ======
 

  setRole(newRole: string) {
    this.role = newRole;
  }

}
