import { TestBed } from '@angular/core/testing';

import { Acservice } from './acservice';

describe('Acservice', () => {
  let service: Acservice;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(Acservice);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
