package com.example.demo;
import org.springframework.stereotype.Component;
@Component
public class Engin {
	public String start() {
	return "Engin Started by setter injection";
	}

}
