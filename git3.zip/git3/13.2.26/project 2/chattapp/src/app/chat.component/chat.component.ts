import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-chat',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './chat.component.html',
  styleUrl: './chat.component.css'
})
export class ChatComponent {

  people = [
    { name: 'Pratt', message: '' },
    { name: 'Sakthi', message: '' },
    { name: 'Anand', message: '' }
  ];

  groupMessages: string[] = [];

  sendMessage(person: any) {
    if (person.message.trim() !== '') {
      this.groupMessages.push(person.name + ': ' + person.message);
      person.message = '';
    }
  }

}
