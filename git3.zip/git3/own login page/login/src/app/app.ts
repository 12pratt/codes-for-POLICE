import { Component } from '@angular/core';
import { LoginComponent } from './login.component/login.component';
import { FormsModule } from '@angular/forms';
@Component({
  selector: 'app-root',
  standalone: true,
  imports: [LoginComponent],
  templateUrl: `app.html`,
})
export class AppComponent {}
