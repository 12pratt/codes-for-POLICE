import { Component, signal } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { Inbuilt } from "./inbuilt/inbuilt";
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet, Inbuilt],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  protected readonly title = signal('jsonpipe');
}
